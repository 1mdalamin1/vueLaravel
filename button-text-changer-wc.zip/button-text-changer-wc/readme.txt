﻿=== Button Text Changer WC ===
Contributors: 1mdalamin1
Donate link: https://www.fiverr.com/share/4Y1RVk
Author URI: https://www.fiverr.com/share/4Y1RVk
Plugin URI: https://wordpress.org/plugins/button-text-changer-wc/
Tags: Add to Cart Text Changer and Customise Button, Button Text Changer WC, Add to Cart Text Changer, Add to Cart, checkout, woocommerce text, Apply coupon, Update Cart, cart, empty cart, Back to shop, Return to Shop.
Requires at least: 5.2
Tested up to: 6.2.2
Stable tag: 1.0.0
License: GPLv2 or later 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Button Text Changer in wooCommerce plugin will help you to put any custom text for wooCommerce button. Now can handle all types of wooCommerce buttons and for all kinds of pages. Like Shop page, Archive page, Single Product page, etc. Easily change WC Button Text. | .It Designed, Developed, Maintained & Supported by vir-za Team.

== Description ==
Button Text Changer WC plugin will help you to enable Button Text Changer WC is a simple solution to Almost like pro features. Now can handle all types of products and for all types page. Like Shop page, Archive page, Single Page, etc. Easily change wooCommerce buttons It is compatible with all major browsers and should work with all themes, including responsive and high resolution themes.

<h4>Text only carousel slider:</h4>
It is very easy to add / edit / delete Button Text Changer via wooCommerce settings tab in admin area -> 

Plugin Documentation: [https://wordpress.org/plugins/button-text-changer-wc/](https://wordpress.org/plugins/button-text-changer-wc/)

*   [Live Demo](https://vir-za.com/cart/)	
*   [Need Help?](https://www.vir-za.com/contact/)		
*   [About Author](https://www.linkedin.com/in/1mdalamin1)


== Video Tutorial ==
[youtube https://www.youtube.com/@1mdalamin1]


==  ⚡ You can changes settings ==
*   No setup needed.
*   any text set in wc button.  
*   Product single page add to cart ajax Button


You can make my day by submitting a positive review on <a href="https://wordpress.org/plugins/button-text-changer-wc/" target="_blank"><strong>WordPress.org!</strong></a></p>

= Usage =

* Go to your Dashboard after installation and wooCommerce settings tab to "btnTextChange".

==  ⚡ Features =
  * Ready to use without any setup
  * Ajax button in single page
  * Very easy installation
  * Flexible and easy to use
  * Lightweight and fast
  * Unlimited btn text change.


== Installation ==

= Minimum Requirements =

* WordPress 4.5 or greater
* PHP version 5.6 or greater
* MySQL version 5.0 or greater

= AUTOMATIC INSTALLATION =

Automatic installation is the easiest option. To automatically install Button Text Changer WC, log in to your WordPress dashboard, navigate the Plugins menu, and click Add New.

In the search field, type Button Text Changer WC, and click Search Plugins. Once you've found our business directory plugin, you install it by clicking Install Now.

= MANUAL INSTALLATION =

The manual installation method involves downloading our Directory plugin and uploading it to your webserver via your favorite FTP application. The WordPress codex will tell you more [here](https://wordpress.org/documentation/article/manage-plugins/). [GeoDirectory basic installation](https://docs.wpgeodirectory.com/category/7-installation)

1. Upload `button-text-changer-wc` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


= UPDATING =

Automatic updates should work seamlessly. We always suggest you backup your website before any automated update to avoid unforeseen problems.

== Frequently asked questions ==
= Is Simple Button Text Changer WC free plugin? =
Yes, Its free WordPress Plugin. 

= Can I customize this? =
Yes, Its easy to customize. 


== Screenshots ==
1. Front End
2. Ticker Settings
3. Back End


== Changelog ==

= 1.0.0 =

* Initial version.

== Upgrade notice ==
N/A.