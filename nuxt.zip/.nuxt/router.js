import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0c96403e = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _9764f98c = () => interopDefault(import('..\\pages\\Backend\\index.vue' /* webpackChunkName: "pages/Backend/index" */))
const _3c810dfc = () => interopDefault(import('..\\pages\\cart.vue' /* webpackChunkName: "pages/cart" */))
const _574c52a7 = () => interopDefault(import('..\\pages\\carts.vue' /* webpackChunkName: "pages/carts" */))
const _86e9224c = () => interopDefault(import('..\\pages\\category.vue' /* webpackChunkName: "pages/category" */))
const _0b5ac9bc = () => interopDefault(import('..\\pages\\checkout.vue' /* webpackChunkName: "pages/checkout" */))
const _62793ff4 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _7f7139ea = () => interopDefault(import('..\\pages\\faq.vue' /* webpackChunkName: "pages/faq" */))
const _1de888e8 = () => interopDefault(import('..\\pages\\my-account.vue' /* webpackChunkName: "pages/my-account" */))
const _161ea01a = () => interopDefault(import('..\\pages\\offers.vue' /* webpackChunkName: "pages/offers" */))
const _b26f42a2 = () => interopDefault(import('..\\pages\\productDetails.vue' /* webpackChunkName: "pages/productDetails" */))
const _36bb4fa4 = () => interopDefault(import('..\\pages\\Search.vue' /* webpackChunkName: "pages/Search" */))
const _7cc60c5b = () => interopDefault(import('..\\pages\\sp-offers.vue' /* webpackChunkName: "pages/sp-offers" */))
const _dcf6a7be = () => interopDefault(import('..\\pages\\wishlist.vue' /* webpackChunkName: "pages/wishlist" */))
const _7410fa31 = () => interopDefault(import('..\\pages\\auth\\forgot-password.vue' /* webpackChunkName: "pages/auth/forgot-password" */))
const _60d0a2d6 = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _fa9333b2 = () => interopDefault(import('..\\pages\\auth\\register.vue' /* webpackChunkName: "pages/auth/register" */))
const _48d24e6a = () => interopDefault(import('..\\pages\\Backend\\abimg.vue' /* webpackChunkName: "pages/Backend/abimg" */))
const _6adf28a7 = () => interopDefault(import('..\\pages\\Backend\\addCategory.vue' /* webpackChunkName: "pages/Backend/addCategory" */))
const _4e905b04 = () => interopDefault(import('..\\pages\\Backend\\addFooter.vue' /* webpackChunkName: "pages/Backend/addFooter" */))
const _5eacc961 = () => interopDefault(import('..\\pages\\Backend\\addFooterTop.vue' /* webpackChunkName: "pages/Backend/addFooterTop" */))
const _288f7c54 = () => interopDefault(import('..\\pages\\Backend\\addProduct.vue' /* webpackChunkName: "pages/Backend/addProduct" */))
const _3bd30b4a = () => interopDefault(import('..\\pages\\Backend\\addSlider.vue' /* webpackChunkName: "pages/Backend/addSlider" */))
const _7355b62e = () => interopDefault(import('..\\pages\\Backend\\addTask.vue' /* webpackChunkName: "pages/Backend/addTask" */))
const _7be5d974 = () => interopDefault(import('..\\pages\\Backend\\addUser.vue' /* webpackChunkName: "pages/Backend/addUser" */))
const _5144900f = () => interopDefault(import('..\\pages\\Backend\\contactMessage.vue' /* webpackChunkName: "pages/Backend/contactMessage" */))
const _53fa4e20 = () => interopDefault(import('..\\pages\\Backend\\editCategory.vue' /* webpackChunkName: "pages/Backend/editCategory" */))
const _5b74ece6 = () => interopDefault(import('..\\pages\\Backend\\editFooter.vue' /* webpackChunkName: "pages/Backend/editFooter" */))
const _57ff2238 = () => interopDefault(import('..\\pages\\Backend\\editFooterTop.vue' /* webpackChunkName: "pages/Backend/editFooterTop" */))
const _42ae3726 = () => interopDefault(import('..\\pages\\Backend\\editProduct.vue' /* webpackChunkName: "pages/Backend/editProduct" */))
const _80ef8c5a = () => interopDefault(import('..\\pages\\Backend\\editSlider.vue' /* webpackChunkName: "pages/Backend/editSlider" */))
const _7666f2f7 = () => interopDefault(import('..\\pages\\Backend\\editTask.vue' /* webpackChunkName: "pages/Backend/editTask" */))
const _7ef7163d = () => interopDefault(import('..\\pages\\Backend\\editUser.vue' /* webpackChunkName: "pages/Backend/editUser" */))
const _5f1ca6de = () => interopDefault(import('..\\pages\\Backend\\profile.vue' /* webpackChunkName: "pages/Backend/profile" */))
const _82dcf490 = () => interopDefault(import('..\\pages\\Backend\\setting.vue' /* webpackChunkName: "pages/Backend/setting" */))
const _abb31d3a = () => interopDefault(import('..\\pages\\Backend\\showCategory.vue' /* webpackChunkName: "pages/Backend/showCategory" */))
const _596aba80 = () => interopDefault(import('..\\pages\\Backend\\showFooter.vue' /* webpackChunkName: "pages/Backend/showFooter" */))
const _23ce18d8 = () => interopDefault(import('..\\pages\\Backend\\showInvoice.vue' /* webpackChunkName: "pages/Backend/showInvoice" */))
const _89bca58e = () => interopDefault(import('..\\pages\\Backend\\showOrder.vue' /* webpackChunkName: "pages/Backend/showOrder" */))
const _03721ccc = () => interopDefault(import('..\\pages\\Backend\\showProduct.vue' /* webpackChunkName: "pages/Backend/showProduct" */))
const _7ee559f4 = () => interopDefault(import('..\\pages\\Backend\\showSlider.vue' /* webpackChunkName: "pages/Backend/showSlider" */))
const _96723fa0 = () => interopDefault(import('..\\pages\\Backend\\showUser.vue' /* webpackChunkName: "pages/Backend/showUser" */))
const _2f8153ea = () => interopDefault(import('..\\pages\\Backend\\taskList.vue' /* webpackChunkName: "pages/Backend/taskList" */))
const _7794369d = () => interopDefault(import('..\\pages\\mixins\\form.js' /* webpackChunkName: "pages/mixins/form" */))
const _7df49900 = () => interopDefault(import('..\\pages\\user\\reset-password.vue' /* webpackChunkName: "pages/user/reset-password" */))
const _196cbaa6 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _17b6195e = () => interopDefault(import('..\\pages\\_slug.vue' /* webpackChunkName: "pages/_slug" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _0c96403e,
    name: "about"
  }, {
    path: "/Backend",
    component: _9764f98c,
    name: "Backend"
  }, {
    path: "/cart",
    component: _3c810dfc,
    name: "cart"
  }, {
    path: "/carts",
    component: _574c52a7,
    name: "carts"
  }, {
    path: "/category",
    component: _86e9224c,
    name: "category"
  }, {
    path: "/checkout",
    component: _0b5ac9bc,
    name: "checkout"
  }, {
    path: "/contact",
    component: _62793ff4,
    name: "contact"
  }, {
    path: "/faq",
    component: _7f7139ea,
    name: "faq"
  }, {
    path: "/my-account",
    component: _1de888e8,
    name: "my-account"
  }, {
    path: "/offers",
    component: _161ea01a,
    name: "offers"
  }, {
    path: "/productDetails",
    component: _b26f42a2,
    name: "productDetails"
  }, {
    path: "/Search",
    component: _36bb4fa4,
    name: "Search"
  }, {
    path: "/sp-offers",
    component: _7cc60c5b,
    name: "sp-offers"
  }, {
    path: "/wishlist",
    component: _dcf6a7be,
    name: "wishlist"
  }, {
    path: "/auth/forgot-password",
    component: _7410fa31,
    name: "auth-forgot-password"
  }, {
    path: "/auth/login",
    component: _60d0a2d6,
    name: "auth-login"
  }, {
    path: "/auth/register",
    component: _fa9333b2,
    name: "auth-register"
  }, {
    path: "/Backend/abimg",
    component: _48d24e6a,
    name: "Backend-abimg"
  }, {
    path: "/Backend/addCategory",
    component: _6adf28a7,
    name: "Backend-addCategory"
  }, {
    path: "/Backend/addFooter",
    component: _4e905b04,
    name: "Backend-addFooter"
  }, {
    path: "/Backend/addFooterTop",
    component: _5eacc961,
    name: "Backend-addFooterTop"
  }, {
    path: "/Backend/addProduct",
    component: _288f7c54,
    name: "Backend-addProduct"
  }, {
    path: "/Backend/addSlider",
    component: _3bd30b4a,
    name: "Backend-addSlider"
  }, {
    path: "/Backend/addTask",
    component: _7355b62e,
    name: "Backend-addTask"
  }, {
    path: "/Backend/addUser",
    component: _7be5d974,
    name: "Backend-addUser"
  }, {
    path: "/Backend/contactMessage",
    component: _5144900f,
    name: "Backend-contactMessage"
  }, {
    path: "/Backend/editCategory",
    component: _53fa4e20,
    name: "Backend-editCategory"
  }, {
    path: "/Backend/editFooter",
    component: _5b74ece6,
    name: "Backend-editFooter"
  }, {
    path: "/Backend/editFooterTop",
    component: _57ff2238,
    name: "Backend-editFooterTop"
  }, {
    path: "/Backend/editProduct",
    component: _42ae3726,
    name: "Backend-editProduct"
  }, {
    path: "/Backend/editSlider",
    component: _80ef8c5a,
    name: "Backend-editSlider"
  }, {
    path: "/Backend/editTask",
    component: _7666f2f7,
    name: "Backend-editTask"
  }, {
    path: "/Backend/editUser",
    component: _7ef7163d,
    name: "Backend-editUser"
  }, {
    path: "/Backend/profile",
    component: _5f1ca6de,
    name: "Backend-profile"
  }, {
    path: "/Backend/setting",
    component: _82dcf490,
    name: "Backend-setting"
  }, {
    path: "/Backend/showCategory",
    component: _abb31d3a,
    name: "Backend-showCategory"
  }, {
    path: "/Backend/showFooter",
    component: _596aba80,
    name: "Backend-showFooter"
  }, {
    path: "/Backend/showInvoice",
    component: _23ce18d8,
    name: "Backend-showInvoice"
  }, {
    path: "/Backend/showOrder",
    component: _89bca58e,
    name: "Backend-showOrder"
  }, {
    path: "/Backend/showProduct",
    component: _03721ccc,
    name: "Backend-showProduct"
  }, {
    path: "/Backend/showSlider",
    component: _7ee559f4,
    name: "Backend-showSlider"
  }, {
    path: "/Backend/showUser",
    component: _96723fa0,
    name: "Backend-showUser"
  }, {
    path: "/Backend/taskList",
    component: _2f8153ea,
    name: "Backend-taskList"
  }, {
    path: "/mixins/form",
    component: _7794369d,
    name: "mixins-form"
  }, {
    path: "/user/reset-password",
    component: _7df49900,
    name: "user-reset-password"
  }, {
    path: "/",
    component: _196cbaa6,
    name: "index"
  }, {
    path: "/:slug",
    component: _17b6195e,
    name: "slug"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
