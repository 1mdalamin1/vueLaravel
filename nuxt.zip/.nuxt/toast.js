import { createToastInterface } from "vue-toastification";

export default function (ctx, inject) {
  const toast = createToastInterface({"cssFile":"C:\\xampp\\htdocs\\sbgs.vir-za.com\\nuxt\\node_modules\\vue-toastification\\dist\\index.css","timeout":1000,"draggable":true});
  inject('toast', toast);
}
