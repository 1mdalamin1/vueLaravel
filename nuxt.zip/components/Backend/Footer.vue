<template >
  <div>
    <footer class="main-footer">
      <strong>Copyright <a href="https://vir-za.com">© 2022 Tanvir Md. Al Amin</a>.</strong> All rights reserved.
    </footer>
  </div>
</template>
<script>
export default {

}
</script>

<style scoped>

</style>
