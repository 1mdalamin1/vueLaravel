
<template>
    <div style="background: white; height:70vh">
        <v-container>
           <h2 class=" text-4xl text-red-500 font-bold text-center">Wishlist Page</h2>
            <div class="row">


            </div>
        </v-container>
    </div>
</template>

<script>
export default {

  head: {
    title: "Wishlist",
  },
    data: function() {
        return {
            // categories: [],
            // category: ''
        }
    },

}
</script>

<style>
    .vcard--reveal{
        align-items: center;
        bottom: 0;
        justify-content: center;
        opacity: 0.8;
        position: absolute;
        width: 100%;
    }
</style>
